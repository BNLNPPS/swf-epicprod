#ifndef EICAFTERBURNER_EICCONFIGURATOR_HH
#define EICAFTERBURNER_EICCONFIGURATOR_HH

#include "AfterburnerConfig.hh"
#include <HepMC3/GenParticle.h>

namespace ab {
    enum class EicBeamPresets {
        Ip6HighDivergence=1, // IP8 High Divergence Config - CDR Table 3.3
        Ip6HighAcceptance=2, // IP8 High Acceptance Config - CDR Table 3.4
        Ip6ElectronAurum=3,  // IP8 eA Config - CDR Table 3.5
        Ip8HighDivergence=4, // IP6 (temporary) High Divergence Config - CDR Table 3.3
        Ip8HighAcceptance=5, // IP6 (temporary) High Acceptance Config - CDR Table 3.4
        Ip8ElectronAurum=6   // IP6 (temporary) eA Config - CDR Table 3.5
    };

    enum class EicBeamEnergies {
        E5GeV = 5,
		E9GeV = 9,
        E10GeV = 10,
        E18GeV = 18,
        E41GeV = 41,
        E100GeV = 100,
        E110GeV = 110,
        E115GeV = 115,
        E130GeV = 130,
        E166GeV = 166,
        E250GeV = 250,
        E275GeV = 275
    };

    class EicConfigurator {
    public:
		//Adding 9 GeV configurations here -- keeping them separate because no 9 GeV tables currently exist as of May 2026
		//need to revisit once the project provide updated numbers.
		//also purposefully not including the IP8 configurations right now
		
        static AfterburnerConfig preset_ip6_eRu_115x9(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_eCu_115x9(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_eHe3_166x9(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_eD_130x9(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_ep_130x9(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_ep_250x9(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_eAu_100x9(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_eAu_110x9();
        static AfterburnerConfig preset_ip6_ePb_100x9();
        static AfterburnerConfig preset_ip6_ePb_110x9();
        static AfterburnerConfig preset_ip6_hiacc_100x9();
        static AfterburnerConfig preset_ip6_hiacc_275x9();
        static AfterburnerConfig preset_ip6_hidiv_100x9();
        static AfterburnerConfig preset_ip6_hidiv_275x9();
		
		/////////////////////////////////////////////////
		
        static AfterburnerConfig preset_ip6_eRu_115x10(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_eCu_115x10(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_eHe3_166x10(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_eD_130x10(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_ep_130x10(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_ep_250x10(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_eAu_100x10(); //EIC early-science option -- only approximate for now
        static AfterburnerConfig preset_ip6_ePb_41x5();
        static AfterburnerConfig preset_ip6_ePb_110x5();
        static AfterburnerConfig preset_ip6_ePb_100x10();
        static AfterburnerConfig preset_ip6_ePb_110x10();
        static AfterburnerConfig preset_ip6_ePb_110x18();


        static AfterburnerConfig preset_ip6_eAu_41x5();
        static AfterburnerConfig preset_ip6_eAu_110x5();
        static AfterburnerConfig preset_ip6_eAu_110x10();
        static AfterburnerConfig preset_ip6_eAu_110x18();
        static AfterburnerConfig preset_ip6_hiacc_41x5();
        static AfterburnerConfig preset_ip6_hiacc_100x5();
        static AfterburnerConfig preset_ip6_hiacc_100x10();
        static AfterburnerConfig preset_ip6_hiacc_275x10();
        static AfterburnerConfig preset_ip6_hiacc_275x18();
        static AfterburnerConfig preset_ip6_hidiv_41x5();
        static AfterburnerConfig preset_ip6_hidiv_100x5();
        static AfterburnerConfig preset_ip6_hidiv_100x10();
        static AfterburnerConfig preset_ip6_hidiv_275x10();
        static AfterburnerConfig preset_ip6_hidiv_275x18();
        
		//IP8 configurations for the second detector
		static AfterburnerConfig preset_ip8_eau_41x5();
        static AfterburnerConfig preset_ip8_eau_110x5();
        static AfterburnerConfig preset_ip8_eau_110x10();
        static AfterburnerConfig preset_ip8_eau_110x18();
        static AfterburnerConfig preset_ip8_hiacc_41x5();
        static AfterburnerConfig preset_ip8_hiacc_100x5();
        static AfterburnerConfig preset_ip8_hiacc_100x10();
        static AfterburnerConfig preset_ip8_hiacc_275x10();
        static AfterburnerConfig preset_ip8_hiacc_275x18();
        static AfterburnerConfig preset_ip8_hidiv_41x5();
        static AfterburnerConfig preset_ip8_hidiv_100x5();
        static AfterburnerConfig preset_ip8_hidiv_100x10();
        static AfterburnerConfig preset_ip8_hidiv_275x10();
        static AfterburnerConfig preset_ip8_hidiv_275x18();
        static AfterburnerConfig from_string(const std::string& name);

        static AfterburnerConfig config(HepMC3::ConstGenParticlePtr ion, HepMC3::ConstGenParticlePtr electron, EicBeamPresets beam_preset);
        static AfterburnerConfig config(EicBeamEnergies ion, EicBeamEnergies electron, EicBeamPresets beam_preset);

    private:

    };
}


#endif //EICAFTERBURNER_EICCONFIGURATOR_HH
